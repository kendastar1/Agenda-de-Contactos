/* ============================================================
   COMPONENTE: PUNTO DE ENTRADA (composición de la aplicación)
   Aquí se crean y conectan todas las piezas, una sola vez:
   Adapter -> Repository (Singleton) -> Strategy (Contexto) ->
   Servicio (Observer) -> Vista -> Controlador.
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
    const almacenamiento = new AdaptadorAlmacenamiento(window.localStorage);
    const repositorio = RepositorioContactos.obtenerInstancia(almacenamiento);
    const contextoResumen = new ContextoResumen([new ResumenPorCategoria(), new CumpleanosDelMes()]);
    const agenda = new AgendaServicio(repositorio, contextoResumen);

    cargarContactosDemo(agenda, almacenamiento);

    const vista = new VistaAgenda();
    const controlador = new ControladorAgenda(agenda, vista);
    iniciarEfectosVisuales();
    controlador.iniciar();
});
