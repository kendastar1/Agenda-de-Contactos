/* ============================================================
   COMPONENTE: MODELO (lógica de la aplicación / fachada del dominio)
   PATRONES: Observer (es el Subject: extiende Observable y notifica los
   cambios), Strategy (delega los resúmenes en el ContextoResumen),
   Repository (persiste solo a través de RepositorioContactos) y
   Factory (crea los contactos con FabricaContactos).
   Es la única puerta de entrada del Controlador al Modelo. No toca el DOM.
   ============================================================ */
class AgendaServicio extends Observable {
    constructor(repositorio, contextoResumen, reloj = () => new Date()) {
        super();
        this.repositorio = repositorio;
        this.contextoResumen = contextoResumen;
        this.reloj = reloj; // inyectable para pruebas de fechas
    }

    hoy() { return this.reloj(); }

    // ---- Operaciones del enunciado ----
    agregar(dto, idFijo = null) {
        const errores = Contacto.validar(dto, this.hoy());
        if (Object.keys(errores).length) return { ok: false, errores };
        const contacto = this.repositorio.guardar(FabricaContactos.desdeDTO(dto, idFijo));
        this.notificar('contactoAgregado', contacto);
        return { ok: true, contacto };
    }

    actualizar(id, dto) {
        if (!this.repositorio.obtenerPorId(id)) return { ok: false, errores: { general: 'El contacto ya no existe' } };
        const errores = Contacto.validar(dto, this.hoy());
        if (Object.keys(errores).length) return { ok: false, errores };
        const contacto = this.repositorio.guardar(FabricaContactos.desdeDTO(dto, id));
        this.notificar('contactoActualizado', contacto);
        return { ok: true, contacto };
    }

    eliminar(id) {
        const eliminado = this.repositorio.eliminar(id);
        if (eliminado) this.notificar('contactoEliminado', id);
        return eliminado;
    }

    obtener(id) { return this.repositorio.obtenerPorId(id); }

    // Lista ordenada alfabéticamente (ignora tildes y mayúsculas)
    listar() {
        return this.repositorio.obtenerTodos()
            .sort((a, b) => compararNombres(a.nombreCompleto, b.nombreCompleto));
    }

    // Búsqueda por nombre parcial; devuelve resultados ya ordenados
    buscarPorNombre(texto) {
        const q = normalizarTexto((texto || '').trim());
        const lista = this.listar();
        return q ? lista.filter(c => normalizarTexto(c.nombreCompleto).includes(q)) : lista;
    }

    // Búsqueda + filtros de la pantalla (categoría, con/sin fecha, orden)
    consultar({ texto = '', categoria = 'todas', fecha = 'todos', orden = 'asc' } = {}) {
        let lista = this.buscarPorNombre(texto);
        if (categoria !== 'todas') lista = lista.filter(c => c.categoria === categoria);
        if (fecha === 'con') lista = lista.filter(c => c.fechaNacimiento);
        if (fecha === 'sin') lista = lista.filter(c => !c.fechaNacimiento);

        const rango = /^([A-Z])-([A-Z])$/.exec(orden);
        if (rango) {
            // Solo nombres cuya inicial cae entre las dos letras (la Ñ cuenta como N)
            lista = lista.filter(c => {
                const inicial = normalizarTexto(c.nombreCompleto).trim().charAt(0).toUpperCase();
                return inicial >= rango[1] && inicial <= rango[2];
            });
        } else if (orden === 'desc') {
            lista.reverse();
        }
        return lista;
    }

    // ---- Resúmenes (Strategy) ----
    resumen(id) { return this.contextoResumen.calcular(this.listar(), this.hoy(), id); }
}
