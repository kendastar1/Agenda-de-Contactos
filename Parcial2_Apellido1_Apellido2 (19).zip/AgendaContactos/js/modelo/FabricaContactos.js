/* ============================================================
   COMPONENTE: MODELO (creación de objetos)
   PATRÓN GoF CREACIONAL: Factory (Simple Factory con métodos estáticos).
   Problema que resuelve: un Contacto se puede originar de dos fuentes
   distintas (un DTO del formulario o un objeto plano leído del
   almacenamiento). La fábrica centraliza cómo se normaliza y se
   construye, y el resto del sistema nunca usa "new Contacto" directamente.
   ============================================================ */
class FabricaContactos {
    // Desde el formulario: limpia espacios y asigna identificador
    static desdeDTO(dto, id = null) {
        return new Contacto({
            id: id || generarId(),
            nombreCompleto: dto.nombreCompleto.trim().replace(/\s+/g, ' '),
            telefono: dto.telefono.trim(),
            email: dto.email.trim(),
            categoria: dto.categoria,
            fechaNacimiento: dto.fechaNacimiento,
            foto: dto.foto
        });
    }

    // Desde el almacenamiento: los datos ya fueron normalizados al guardarse
    static desdeRegistro(registro) {
        return new Contacto(registro);
    }
}
