/* ============================================================
   COMPONENTE: MODELO (catálogo del dominio)
   PATRONES: ninguno. Categorías válidas del enunciado y nombres de meses.
   ============================================================ */
const CATEGORIAS = Object.freeze({
    familia: 'Familia',
    trabajo: 'Trabajo',
    estudio: 'Estudio',
    amigos:  'Amigos',
    otros:   'Otros'
});

const MESES = Object.freeze(['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio',
                             'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']);
