/* ============================================================
   COMPONENTE: MODELO (infraestructura de notificación)
   PATRÓN GoF DE COMPORTAMIENTO: Observer (parte "Subject").
   Problema que resuelve: cuando la agenda cambia (agregar, editar,
   eliminar) la pantalla debe actualizarse SIN que el Modelo conozca la
   Vista. El Modelo solo avisa; quien esté suscrito reacciona.
   ============================================================ */
class Observable {
    #observadores = new Set();

    // Devuelve una función para cancelar la suscripción
    suscribir(observador) {
        this.#observadores.add(observador);
        return () => this.#observadores.delete(observador);
    }

    notificar(evento, datos = null) {
        this.#observadores.forEach(observador => observador(evento, datos));
    }
}
