/* ============================================================
   COMPONENTE: MODELO (entidad Contacto + reglas de negocio)
   PATRONES: ninguno propio (es creada por la Factory FabricaContactos).
   Aquí viven TODAS las reglas de validación: la Vista solo muestra
   los mensajes. No toca el DOM.
   ============================================================ */
class Contacto {
    constructor({ id, nombreCompleto, telefono, email, categoria, fechaNacimiento = null, foto = null }) {
        this.id = id;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.email = email;
        this.categoria = categoria;
        this.fechaNacimiento = fechaNacimiento || null; // opcional
        this.foto = foto || null;                       // opcional (data URL)
    }

    // Regla de negocio: devuelve { campo: mensaje } (vacío = datos válidos)
    static validar(datos, hoy = new Date()) {
        const errores = {};
        const nombre = (datos.nombreCompleto || '').trim();
        const telefono = (datos.telefono || '').trim();
        const email = (datos.email || '').trim();

        if (!nombre) errores.nombreCompleto = 'El nombre completo es obligatorio';
        else if (!/^[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ.'\-\s]+$/.test(nombre)) errores.nombreCompleto = 'Solo se permiten letras y espacios';

        if (!telefono) errores.telefono = 'El teléfono es obligatorio';
        else if (!/^\+?\d{7,15}$/.test(telefono)) errores.telefono = 'Use entre 7 y 15 dígitos (puede iniciar con +)';

        if (!email) errores.email = 'El email es obligatorio';
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errores.email = 'Email no válido';

        if (!datos.categoria || !(datos.categoria in CATEGORIAS)) errores.categoria = 'Seleccione una categoría';

        if (datos.fechaNacimiento) {
            const f = parsearFecha(datos.fechaNacimiento);
            const fecha = new Date(f.anio, f.mes - 1, f.dia);
            if (isNaN(fecha.getTime())) errores.fechaNacimiento = 'Fecha inválida';
            else if (fecha > hoy) errores.fechaNacimiento = 'La fecha de nacimiento no puede ser futura';
        }
        return errores;
    }

    cumpleEnMes(mes) {
        const f = parsearFecha(this.fechaNacimiento);
        return Boolean(f) && f.mes === mes;
    }

    cumpleHoy(hoy) {
        const f = parsearFecha(this.fechaNacimiento);
        return Boolean(f) && f.mes === hoy.getMonth() + 1 && f.dia === hoy.getDate();
    }
}
