/* ============================================================
   COMPONENTE: MODELO (objeto de transferencia de datos)
   PATRÓN ARQUITECTÓNICO: DTO (Data Transfer Object).
   Es el ÚNICO formato en que viajan los datos del formulario desde la
   Vista/Controlador hacia el Modelo. Inmutable y sin comportamiento.
   ============================================================ */
class ContactoDTO {
    constructor({ nombreCompleto = '', telefono = '', email = '', categoria = '', fechaNacimiento = '', foto = null } = {}) {
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.email = email;
        this.categoria = categoria;
        this.fechaNacimiento = fechaNacimiento;
        this.foto = foto;
        Object.freeze(this);
    }

    static desdeContacto(contacto) {
        return new ContactoDTO({ ...contacto, fechaNacimiento: contacto.fechaNacimiento || '' });
    }
}
