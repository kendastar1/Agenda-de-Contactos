/* ============================================================
   COMPONENTE: UTILIDADES (funciones puras, sin estado ni DOM)
   PATRONES: ninguno.
   ============================================================ */

// Escapa texto antes de insertarlo como HTML (evita inyección)
function escaparHtml(texto) {
    return String(texto ?? '').replace(/[&<>"']/g, c => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
}

// Compara sin mayúsculas ni tildes ("jose" encuentra "José")
function normalizarTexto(texto) {
    return String(texto ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

// 'AAAA-MM-DD' -> { anio, mes (1-12), dia } sin problemas de zona horaria
function parsearFecha(iso) {
    if (!iso) return null;
    const [anio, mes, dia] = iso.split('-').map(Number);
    return { anio, mes, dia };
}

function formatearFecha(iso) {
    const f = parsearFecha(iso);
    return f ? `${String(f.dia).padStart(2, '0')}/${String(f.mes).padStart(2, '0')}/${f.anio}` : '—';
}

function generarId() {
    return (crypto.randomUUID && crypto.randomUUID()) || `c_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function compararNombres(a, b) {
    return a.localeCompare(b, 'es', { sensitivity: 'base' });
}
