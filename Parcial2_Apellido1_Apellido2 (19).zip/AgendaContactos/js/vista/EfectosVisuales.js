/* ============================================================
   COMPONENTE: VISTA (efectos puramente visuales)
   PATRONES: ninguno. Pantalla de carga, barra superior fija, menú móvil.
   No contiene reglas de negocio ni accede al Modelo.
   ============================================================ */
function iniciarEfectosVisuales() {
    // ============================================================
    //  ANIMACIÓN DE CARGA (pantalla inicial + aparición progresiva)
    // ============================================================
    (function () {
        const TIEMPO_MINIMO = 1400; // ms que se muestra la animación como mínimo
        const inicio = performance.now();
        let terminado = false;

        function ocultarLoader() {
            if (terminado) return;
            terminado = true;
            const loader = document.getElementById('pageLoader');
            document.body.classList.remove('is-loading');   // dispara la aparición escalonada
            // La entrada de las tarjetas ocurre solo en la carga inicial; luego se apaga
            // para que no se repita al repintar la lista (volver a la pestaña, filtrar, editar).
            setTimeout(() => document.body.classList.remove('animar-tarjetas'), 2000);
            if (loader) {
                loader.classList.add('done');
                setTimeout(() => loader.remove(), 700);
            }
        }
        function programar() {
            const resta = Math.max(0, TIEMPO_MINIMO - (performance.now() - inicio));
            setTimeout(ocultarLoader, resta);
        }
        if (document.readyState === 'complete') programar();
        else window.addEventListener('load', programar);
        setTimeout(ocultarLoader, 5000); // seguro por si algún recurso externo tarda demasiado
    })();

    // Barra superior fija: sombra sutil al bajar y espacio reservado para que no tape el contenido
    (function () {
        const topbar = document.querySelector('.topbar');
        if (!topbar) return;
        const actualizar = () => topbar.classList.toggle('is-stuck', window.scrollY > 8);
        window.addEventListener('scroll', actualizar, { passive: true });
        actualizar();

        const medir = () => document.documentElement.style.setProperty('--topbar-h', topbar.offsetHeight + 'px');
        medir();
        window.addEventListener('resize', medir);
        if ('ResizeObserver' in window) new ResizeObserver(medir).observe(topbar);
    })();

    // Botón del hero: lleva al listado de contactos
    document.getElementById('btnIrContactos').addEventListener('click', () => {
        const destino = document.querySelector('.list-title') || document.getElementById('gridContactos');
        destino.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    // Menú lateral en móvil
    const alternar = document.getElementById('mobileMenuToggle');
    const lateral = document.getElementById('sidebar');
    const velo = document.getElementById('sidebarOverlay');
    const cerrarMenu = () => {
        lateral.classList.remove('mobile-active');
        velo.classList.remove('active');
        document.body.style.overflow = '';
        alternar.innerHTML = '<i class="fas fa-bars"></i>';
    };
    alternar.addEventListener('click', ev => {
        ev.preventDefault();
        if (lateral.classList.contains('mobile-active')) return cerrarMenu();
        lateral.classList.add('mobile-active');
        velo.classList.add('active');
        document.body.style.overflow = 'hidden';
        alternar.innerHTML = '<i class="fas fa-times"></i>';
    });
    velo.addEventListener('click', cerrarMenu);
}
