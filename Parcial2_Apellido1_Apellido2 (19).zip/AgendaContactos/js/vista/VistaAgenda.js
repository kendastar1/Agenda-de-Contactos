/* ============================================================
   COMPONENTE: VISTA (pasiva)
   PATRONES: MVC (rol de Vista). Es "pasiva": recibe datos ya calculados
   y los dibuja; ante una acción del usuario solo llama al manejador que
   le entrega el Controlador. NO valida reglas de negocio (solo muestra los
   errores que le llegan) y NO conoce el repositorio ni las estrategias.
   ============================================================ */
const porId = id => document.getElementById(id);

const ICONOS_CAT = {
    todas: 'fa-th-large', familia: 'fa-heart', trabajo: 'fa-briefcase',
    estudio: 'fa-graduation-cap', amigos: 'fa-user-friends', otros: 'fa-bookmark'
};

const ORDENES = [
    { id: 'asc',  boton: 'Nombre (A → Z)', marca: 'A→Z', texto: 'De la A a la Z',  sub: 'Orden alfabético' },
    { id: 'desc', boton: 'Nombre (Z → A)', marca: 'Z→A', texto: 'De la Z a la A',  sub: 'Orden alfabético inverso' },
    { id: 'A-E',  boton: 'Letras A – E',   marca: 'A–E', texto: 'De la A a la E', sub: 'Empiezan por A, B, C, D o E' },
    { id: 'F-J',  boton: 'Letras F – J',   marca: 'F–J', texto: 'De la F a la J', sub: 'Empiezan por F, G, H, I o J' },
    { id: 'K-O',  boton: 'Letras K – O',   marca: 'K–O', texto: 'De la K a la O', sub: 'Empiezan por K, L, M, N u O' },
    { id: 'P-T',  boton: 'Letras P – T',   marca: 'P–T', texto: 'De la P a la T', sub: 'Empiezan por P, Q, R, S o T' },
    { id: 'U-Z',  boton: 'Letras U – Z',   marca: 'U–Z', texto: 'De la U a la Z', sub: 'Empiezan por U, V, W, X, Y o Z' }
];

const BOTONES_CON_FEEDBACK = '#btnNuevoContacto, #btnIrContactos, #bellBtn, .btn-outline[data-accion], .card-del, .btn-save, .btn-cancel';
const CAMPOS_FORMULARIO = ['nombreCompleto', 'telefono', 'email', 'categoria', 'fechaNacimiento'];
const FOTO_VACIA = '<i class="fas fa-user-circle default-user-icon"></i>';
const FOTO_MAX_BYTES = 5 * 1024 * 1024;
const MODALES = ['contactoModal', 'viewModal', 'deleteModal'];

class VistaAgenda {
    #temporizadorAltura = null;
    #temporizadorLista = null;

    // ---------------------------------------------------------
    //  Enlace con el Controlador: cada evento del usuario se
    //  reenvía a un manejador, sin tomar decisiones aquí.
    // ---------------------------------------------------------
    enlazar(m) {
        porId('btnNuevoContacto').addEventListener('click', () => m.nuevoContacto());

        // Feedback visual al hacer clic en los botones principales (la animación se reinicia en cada clic)
        document.addEventListener('click', ev => {
            const boton = ev.target.closest(BOTONES_CON_FEEDBACK);
            if (boton) this.#pulsarBoton(boton);
        });

        const buscador = porId('buscador');
        buscador.addEventListener('input', () => { this.#fijarAlturaLista(); m.buscar(buscador.value); });
        // Se libera con un pequeño retraso: si se libera al instante, la lista se encoge al hacer
        // mousedown sobre un botón, el botón se mueve y el primer clic se pierde.
        buscador.addEventListener('blur', () => { this.#temporizadorAltura = setTimeout(() => this.#liberarAlturaLista(), 400); });

        porId('strategyResultado').addEventListener('click', ev => {
            const tarjeta = ev.target.closest('.summary-card');
            if (tarjeta) m.elegirCategoria(tarjeta.dataset.cat);
        });
        document.querySelector('.nav-menu').addEventListener('click', ev => {
            const item = ev.target.closest('.nav-item');
            if (!item) return;
            document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n === item));
            if (item.dataset.nav === 'inicio') {
                window.scrollTo({ top: 0, behavior: 'smooth' });   // arriba: "Tu directorio personal"
            } else {
                porId(item.dataset.nav === 'resumen' ? 'panelReportes' : 'gridContactos')
                    .scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
            porId('sidebarOverlay').click();
        });

        porId('pillsFecha').addEventListener('click', ev => {
            const pill = ev.target.closest('.pill');
            if (pill) m.elegirFecha(pill.dataset.fecha);
        });
        porId('ordenBtn').addEventListener('click', ev => { ev.stopPropagation(); this.#alternarOrden(); });
        porId('ordenLista').addEventListener('click', ev => {
            const fila = ev.target.closest('[data-orden]');
            if (!fila) return;
            this.#alternarOrden(false);
            m.elegirOrden(fila.dataset.orden);
        });
        porId('btnLimpiar').addEventListener('click', () => m.limpiarFiltros());

        porId('pagination').addEventListener('click', ev => {
            const item = ev.target.closest('[data-pag]');
            const destino = item ? Number(item.dataset.pag) : 0;
            if (destino >= 1) {
                m.irAPagina(destino);
                porId('gridContactos').scrollIntoView({ behavior: 'smooth', block: 'start' });
                // La paginación se vuelve a dibujar: se anima el elemento nuevo (la flecha pulsada o la página activa)
                const nuevo = item.title ? porId('pagination').querySelector(`[title="${item.title}"]`) : porId('pagination').querySelector('.page-item.active');
                if (nuevo) this.#pulsarBoton(nuevo);
            }
        });
        porId('gridContactos').addEventListener('click', ev => {
            const boton = ev.target.closest('[data-accion]');
            if (!boton) return;
            const { accion, id } = boton.dataset;
            if (accion === 'ver') m.verContacto(id);
            if (accion === 'editar') m.editarContacto(id);
            if (accion === 'eliminar') m.pedirEliminar(id);
        });

        porId('contactoForm').addEventListener('submit', ev => { ev.preventDefault(); m.guardar(); });
        porId('fotoInput').addEventListener('change', ev => m.elegirFoto(ev.target.files[0] || null));
        porId('confirmDeleteBtn').addEventListener('click', () => m.confirmarEliminar());
        CAMPOS_FORMULARIO.forEach(id => {
            ['input', 'change'].forEach(tipo => porId(id).addEventListener(tipo, () => this.#limpiarErrorCampo(id)));
        });

        // Campanita
        porId('bellBtn').addEventListener('click', ev => { ev.stopPropagation(); this.#alternarCampana(); });
        document.addEventListener('click', ev => {
            if (!ev.target.closest('.bell-wrap')) this.#alternarCampana(false);
            if (!ev.target.closest('.order-wrap')) this.#alternarOrden(false);
        });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) m.pestanaVisible(); });

        // Modales: botones "cerrar", clic en el fondo y tecla Esc
        document.querySelectorAll('[data-cerrar]').forEach(b => b.addEventListener('click', () => this.cerrarModal(b.dataset.cerrar)));
        document.querySelectorAll('.modal').forEach(modal =>
            modal.addEventListener('click', ev => { if (ev.target === modal) this.cerrarModal(modal.id); }));
        document.addEventListener('keydown', ev => {
            if (ev.key !== 'Escape') return;
            this.#alternarCampana(false);
            this.#alternarOrden(false);
            MODALES.forEach(id => this.cerrarModal(id));
        });
    }

    // ---------------------------------------------------------
    //  Resumen por categoría (resultado de la estrategia ResumenPorCategoria)
    // ---------------------------------------------------------
    renderizarResumen(resumen, categoriaActiva) {
        porId('strategyResultado').innerHTML = this.#htmlResumenCategorias(resumen, categoriaActiva);
    }

    #htmlResumenCategorias(resumen, categoriaActiva) {
        const tarjetas = resumen.categorias.map(({ clave, etiqueta, cantidad }) => `
            <button type="button" class="summary-total-card summary-card cat-${clave} ${DECO_TARJETAS[clave] ? 'has-deco' : ''} ${categoriaActiva === clave ? 'active' : ''}"
                    data-cat="${clave}" title="Filtrar por ${etiqueta}">
                ${decoTarjeta(clave)}
                <span class="summary-total-icon"><i class="fas ${ICONOS_CAT[clave]}"></i></span>
                <span class="summary-total-num">${cantidad}</span>
                <span class="summary-total-label">${etiqueta}</span>
            </button>`).join('');

        return `<div class="summary-grid ${categoriaActiva !== 'todas' ? 'has-filter' : ''}">
                    <button type="button" class="summary-total-card summary-card summary-main has-deco ${categoriaActiva === 'todas' ? 'active' : ''}"
                            data-cat="todas" title="Ver todos los contactos">
                        ${decoTarjeta('todas')}
                        <span class="summary-total-icon"><i class="fas fa-users"></i></span>
                        <span class="summary-total-num">${resumen.total}</span>
                        <span class="summary-total-label">${resumen.total === 1 ? 'contacto en total' : 'contactos en total'}</span>
                    </button>
                    ${tarjetas}
                </div>`;
    }

    #htmlFilaCumple({ contacto: c, dia, edad, esHoy, diasFaltantes }) {
        const cat = c.categoria in CATEGORIAS ? c.categoria : 'otros';
        const avatar = c.foto ? `<img src="${c.foto}" alt="Foto">` : escaparHtml(c.nombreCompleto.charAt(0).toUpperCase());
        const insignia = esHoy ? '<span class="bday-badge hoy">¡Hoy!</span>'
            : diasFaltantes < 0 ? '<span class="bday-badge paso">Ya pasó</span>'
            : `<span class="bday-badge">En ${diasFaltantes} día(s)</span>`;
        return `
            <li class="bday-row cat-${cat} ${esHoy ? 'es-hoy' : ''}">
                <div class="bday-avatar">${avatar}</div>
                <div class="bday-text">
                    <div class="bday-name">${escaparHtml(c.nombreCompleto)}</div>
                    <div class="bday-sub">Día ${dia} · ${edad} años · ${escaparHtml(CATEGORIAS[cat])}</div>
                </div>
                ${insignia}
                <a class="bday-call" href="tel:${encodeURIComponent(c.telefono)}" title="Llamar a ${escaparHtml(c.nombreCompleto)}"><i class="fas fa-phone-alt"></i></a>
            </li>`;
    }

    // ---------------------------------------------------------
    //  Torta de cumpleaños: lista TODOS los del mes (resultado de la estrategia
    //  CumpleanosDelMes); a quien cumple hoy se le marca con un aro morado.
    //  La torta se mueve y aparece el punto rojo solo si alguien cumple hoy.
    // ---------------------------------------------------------
    renderizarCampana(resumenMes, hoy) {
        const hayHoy = resumenMes.items.some(i => i.esHoy);
        const boton = porId('bellBtn');
        boton.classList.toggle('ringing', hayHoy);
        porId('bellDot').hidden = !hayHoy;
        boton.title = hayHoy ? '¡Hoy hay cumpleaños!' : `Cumpleaños de ${resumenMes.nombreMes}`;
        porId('bellTitulo').textContent = `Cumpleaños de ${resumenMes.nombreMes}`;
        porId('bellFecha').textContent = `Hoy es ${hoy.getDate()} de ${MESES[hoy.getMonth()]} · ${resumenMes.items.length} contacto(s) este mes`;
        porId('bellContenido').innerHTML = resumenMes.items.length === 0
            ? `<div class="bday-empty"><i class="fas fa-birthday-cake"></i>Nadie cumple años en ${escaparHtml(resumenMes.nombreMes)}</div>`
            : `<ul class="bday-list">${resumenMes.items.map(i => this.#htmlFilaCumple(i)).join('')}</ul>`;
    }

    #alternarCampana(abrir) {
        const panel = porId('bellPanel');
        const mostrar = abrir ?? panel.hidden;
        panel.hidden = !mostrar;
        porId('bellBtn').setAttribute('aria-expanded', String(mostrar));
    }

    // ---------------------------------------------------------
    //  Filtros
    // ---------------------------------------------------------
    renderizarFiltros(filtros, porCategoria) {
        const cont = porId('catSeleccionada');
        if (filtros.categoria === 'todas') {
            cont.innerHTML = `<span class="cat-selected-badge cat-todas"><i class="fas fa-users"></i> Todos los contactos <small>(${porCategoria.total})</small></span>`;
        } else {
            const k = filtros.categoria;
            const n = porCategoria.categorias.find(c => c.clave === k).cantidad;
            cont.innerHTML = `<span class="cat-selected-badge cat-${k}"><i class="fas ${ICONOS_CAT[k]}"></i> ${escaparHtml(CATEGORIAS[k])} <small>(${n})</small></span>`;
        }

        document.querySelectorAll('#pillsFecha .pill').forEach(p => p.classList.toggle('active', p.dataset.fecha === filtros.fecha));

        const actual = ORDENES.find(o => o.id === filtros.orden) || ORDENES[0];
        porId('ordenLabel').textContent = actual.boton;
        porId('ordenLista').innerHTML = ORDENES.map(o => `
            <li>
                <button type="button" class="order-row ${o.id === actual.id ? 'active' : ''}" role="option" aria-selected="${o.id === actual.id}" data-orden="${o.id}">
                    <span class="order-avatar">${o.marca}</span>
                    <span class="order-text"><span class="order-name">${o.texto}</span><span class="order-sub">${o.sub}</span></span>
                    <i class="fas fa-check order-check"></i>
                </button>
            </li>`).join('');
    }

    #alternarOrden(abrir) {
        const panel = porId('ordenPanel');
        const mostrar = abrir ?? panel.hidden;
        panel.hidden = !mostrar;
        porId('ordenBtn').setAttribute('aria-expanded', String(mostrar));
    }

    limpiarBusqueda() { porId('buscador').value = ''; }

    #pulsarBoton(boton) {
        clearTimeout(boton._temporizadorFx);
        boton.classList.remove('fx-clic');
        void boton.offsetWidth; // fuerza el reflujo para poder repetir la animación
        boton.classList.add('fx-clic');
        boton._temporizadorFx = setTimeout(() => boton.classList.remove('fx-clic'), 700);
    }

    // ---------------------------------------------------------
    //  Retroalimentación visual: una animación breve que confirma que el filtro se aplicó
    //  tipo: 'fecha' | 'orden' | 'limpiar'
    // ---------------------------------------------------------
    animarAccion(tipo, valor) {
        const reiniciar = (el, clase) => {
            if (!el) return;
            el.classList.remove(clase);
            void el.offsetWidth; // fuerza el reflujo para poder repetir la animación
            el.classList.add(clase);
            el.addEventListener('animationend', function fin(ev) {
                if (ev.target !== el && !el.contains(ev.target)) return;
                el.classList.remove(clase);
                el.removeEventListener('animationend', fin);
            });
        };
        if (tipo === 'fecha') reiniciar(document.querySelector(`#pillsFecha .pill[data-fecha="${valor}"]`), 'fx-activo');
        if (tipo === 'orden') reiniciar(porId('ordenBtn'), 'fx-activo');
        if (tipo === 'limpiar') {
            reiniciar(porId('btnLimpiar'), 'fx-activo');
            reiniciar(document.querySelector('.filters'), 'fx-panel');
        }
        // La lista de contactos se vuelve a "acomodar" con una entrada suave
        const grid = porId('gridContactos');
        grid.classList.remove('fx-lista');
        void grid.offsetWidth;
        grid.classList.add('fx-lista');
        clearTimeout(this.#temporizadorLista);
        this.#temporizadorLista = setTimeout(() => grid.classList.remove('fx-lista'), 1100);
    }

    // ---------------------------------------------------------
    //  Lista de contactos + paginación
    // ---------------------------------------------------------
    renderizarLista({ contactos, total, inicio, pagina, totalPaginas, hayFiltro, hoy }) {
        const grid = porId('gridContactos');
        porId('listaConteo').textContent = `(${total})`;

        if (total === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <p>${hayFiltro ? 'Ningún contacto coincide con los filtros' : 'Aún no tienes contactos. ¡Agrega el primero!'}</p>
                </div>`;
            porId('infoMostrando').textContent = '';
            porId('pagination').innerHTML = '';
            return;
        }
        grid.innerHTML = contactos.map(c => this.#htmlTarjeta(c, hoy)).join('');
        [...grid.children].forEach((el, i) => el.style.setProperty('--i', i));
        porId('infoMostrando').textContent = `Mostrando ${inicio + 1} - ${inicio + contactos.length} de ${total} contactos`;
        this.#renderizarPaginacion(pagina, totalPaginas);
    }

    #htmlTarjeta(c, hoy) {
        const cat = c.categoria in CATEGORIAS ? c.categoria : 'otros';
        const etiquetaHoy = c.cumpleHoy(hoy) ? '<span class="tag-hoy"><i class="fas fa-birthday-cake"></i> ¡Hoy!</span>' : '';
        return `
        <article class="contact-card cat-${cat}">
            <button class="card-del" data-accion="eliminar" data-id="${c.id}" title="Eliminar" aria-label="Eliminar"><i class="fas fa-trash-alt"></i></button>
            <div class="card-avatar">${c.foto ? `<img src="${c.foto}" alt="Foto">` : escaparHtml(this.#iniciales(c.nombreCompleto))}</div>
            <h3 class="card-name">${escaparHtml(c.nombreCompleto)}</h3>
            <div class="card-role">@ ${escaparHtml(CATEGORIAS[cat])}</div>
            ${etiquetaHoy}
            <div class="card-actions">
                <button class="btn-outline" data-accion="ver" data-id="${c.id}">Ver</button>
                <button class="btn-outline" data-accion="editar" data-id="${c.id}">Editar</button>
            </div>
        </article>`;
    }

    #iniciales(nombre) {
        const partes = nombre.split(' ').filter(Boolean);
        return ((partes[0] || '')[0] + (partes[1] ? partes[1][0] : '')).toUpperCase();
    }

    #renderizarPaginacion(pagina, totalPaginas) {
        const cont = porId('pagination');
        if (totalPaginas <= 1) { cont.innerHTML = ''; return; }
        // Visibles: primera, última, la actual y sus vecinas; el resto se resume con "…"
        const visibles = new Set([1, totalPaginas, pagina - 1, pagina, pagina + 1]);
        if (pagina <= 3) [2, 3, 4].forEach(n => visibles.add(n));
        if (pagina >= totalPaginas - 2) [1, 2, 3].forEach(k => visibles.add(totalPaginas - k));
        const numeros = [...visibles].filter(n => n >= 1 && n <= totalPaginas).sort((x, y) => x - y);

        let html = `<span class="page-item ${pagina === 1 ? 'disabled' : ''}" data-pag="${pagina - 1}" title="Anterior"><i class="fas fa-chevron-left"></i></span>`;
        let previa = 0;
        numeros.forEach(n => {
            if (n - previa > 1) html += '<span class="page-gap">…</span>';
            html += `<span class="page-item ${n === pagina ? 'active' : ''}" data-pag="${n}">${n}</span>`;
            previa = n;
        });
        html += `<span class="page-item ${pagina === totalPaginas ? 'disabled' : ''}" data-pag="${pagina + 1}" title="Siguiente"><i class="fas fa-chevron-right"></i></span>`;
        cont.innerHTML = html;
    }

    // Mientras se escribe se fija la altura de la lista: si no, la página se encoge y el scroll salta
    #fijarAlturaLista() {
        clearTimeout(this.#temporizadorAltura);
        const grid = porId('gridContactos');
        if (!grid.dataset.alturaFija) {
            grid.style.minHeight = grid.offsetHeight + 'px';
            const pie = document.querySelector('.list-footer');
            if (pie) pie.style.minHeight = pie.offsetHeight + 'px';
            grid.dataset.alturaFija = '1';
        }
        grid.classList.add('sin-anim');
    }

    #liberarAlturaLista() {
        const grid = porId('gridContactos');
        grid.style.minHeight = '';
        const pie = document.querySelector('.list-footer');
        if (pie) pie.style.minHeight = '';
        delete grid.dataset.alturaFija;
        grid.classList.remove('sin-anim');
    }

    // ---------------------------------------------------------
    //  Formulario, detalle y confirmación
    // ---------------------------------------------------------
    abrirFormulario(contacto = null) {
        porId('contactoForm').reset();
        porId('modalTitle').textContent = contacto ? 'Editar Contacto' : 'Nuevo Contacto';
        porId('btnGuardar').textContent = contacto ? 'Actualizar Contacto' : 'Guardar Contacto';
        this.mostrarFoto(contacto ? contacto.foto : null);
        porId('fotoInput').value = '';
        this.#limpiarTodosLosErrores();

        const d = new Date(); // fecha LOCAL (toISOString usaría UTC y desfasaría la fecha de noche)
        porId('fechaNacimiento').max = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

        if (contacto) {
            porId('nombreCompleto').value = contacto.nombreCompleto;
            porId('telefono').value = contacto.telefono;
            porId('email').value = contacto.email;
            porId('categoria').value = contacto.categoria;
            porId('fechaNacimiento').value = contacto.fechaNacimiento || '';
        }
        porId('contactoModal').classList.add('active');
        porId('nombreCompleto').focus({ preventScroll: true });
    }

    // Devuelve los valores crudos del formulario (el Controlador arma el DTO)
    leerFormulario() {
        const valores = {};
        CAMPOS_FORMULARIO.forEach(id => { valores[id] = porId(id).value; });
        return valores;
    }

    mostrarErrores(errores) {
        this.#limpiarTodosLosErrores();
        Object.entries(errores).forEach(([campo, mensaje]) => {
            const input = porId(campo);
            if (!input) return;
            input.classList.add('error');
            const div = document.createElement('div');
            div.className = 'error-message';
            div.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${escaparHtml(mensaje)}`;
            input.closest('.form-group').appendChild(div);
        });
    }

    #limpiarErrorCampo(id) {
        const input = porId(id);
        input.classList.remove('error');
        const err = input.closest('.form-group').querySelector('.error-message');
        if (err) err.remove();
    }

    #limpiarTodosLosErrores() { CAMPOS_FORMULARIO.forEach(id => this.#limpiarErrorCampo(id)); }

    mostrarFoto(dataUrl) {
        porId('fotoPreview').innerHTML = dataUrl ? `<img src="${dataUrl}" alt="Vista previa">` : FOTO_VACIA;
    }

    limpiarInputFoto() { porId('fotoInput').value = ''; }

    // Valida el archivo (tipo y peso), lo reduce a 256 px y devuelve una data URL
    procesarFoto(archivo) {
        return new Promise((resolver, rechazar) => {
            if (!archivo.type.startsWith('image/')) return rechazar(new Error('El archivo debe ser una imagen'));
            if (archivo.size > FOTO_MAX_BYTES) return rechazar(new Error('La imagen supera los 5MB'));
            const lector = new FileReader();
            lector.onload = e => {
                const img = new Image();
                img.onload = () => {
                    const escala = Math.min(1, 256 / Math.max(img.width, img.height));
                    const lienzo = document.createElement('canvas');
                    lienzo.width = Math.round(img.width * escala);
                    lienzo.height = Math.round(img.height * escala);
                    lienzo.getContext('2d').drawImage(img, 0, 0, lienzo.width, lienzo.height);
                    resolver(lienzo.toDataURL('image/jpeg', 0.85));
                };
                img.onerror = () => rechazar(new Error('No se pudo leer la imagen'));
                img.src = e.target.result;
            };
            lector.readAsDataURL(archivo);
        });
    }

    abrirDetalle(c) {
        porId('viewNombreCompleto').textContent = c.nombreCompleto;
        porId('viewTelefono').textContent = c.telefono;
        porId('viewEmail').textContent = c.email;
        porId('viewCategoria').textContent = CATEGORIAS[c.categoria] || c.categoria;
        porId('viewNacimiento').textContent = c.fechaNacimiento ? formatearFecha(c.fechaNacimiento) : 'No registrada';
        porId('viewFoto').innerHTML = c.foto ? `<img src="${c.foto}" alt="Foto">`
            : '<i class="fas fa-user-circle" style="font-size:80px; color:#2563eb;"></i>';
        porId('viewModal').classList.add('active');
    }

    abrirConfirmarEliminar(nombre) {
        porId('deleteNombre').textContent = nombre;
        porId('deleteModal').classList.add('active');
    }

    cerrarModal(id) {
        const modal = porId(id);
        if (!modal.classList.contains('active')) return;
        modal.classList.add('closing');
        setTimeout(() => {
            modal.classList.remove('active', 'closing');
            if (id === 'contactoModal') {
                porId('contactoForm').reset();
                this.mostrarFoto(null);
                this.limpiarInputFoto();
                this.#limpiarTodosLosErrores();
            }
        }, 100);
    }

    // ---------------------------------------------------------
    //  Notificaciones
    // ---------------------------------------------------------
    notificar(mensaje, tipo = 'success') {
        let contenedor = document.querySelector('.notification-container');
        if (!contenedor) {
            contenedor = document.createElement('div');
            contenedor.className = 'notification-container';
            document.body.appendChild(contenedor);
        }
        contenedor.innerHTML = '';

        const titulos = { success: '¡Listo!', error: '¡Error!', warning: 'Atención', info: 'Información' };
        const iconos = {
            success: '<svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/><path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/></svg>',
            error: '<svg class="error-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="error-icon__circle" cx="26" cy="26" r="25" fill="none"/><path class="error-icon__line" fill="none" d="M16 16 L36 36 M36 16 L16 36"/></svg>',
            warning: '<i class="fas fa-exclamation-triangle" style="font-size:32px;"></i>',
            info: '<i class="fas fa-info-circle" style="font-size:32px;"></i>'
        };

        const n = document.createElement('div');
        n.className = `notification ${tipo}`;
        n.innerHTML = `
            <div class="notification-close"><i class="fas fa-times"></i></div>
            <div class="notification-icon">${iconos[tipo] || iconos.info}</div>
            <div class="notification-content">
                <div class="notification-title">${titulos[tipo] || ''}</div>
                <div class="notification-message">${escaparHtml(mensaje)}</div>
            </div>`;
        contenedor.appendChild(n);
        contenedor.classList.add('con-fondo');

        let cerrando = false;
        const cerrar = () => {
            if (cerrando || !n.parentNode) return;
            cerrando = true;
            clearTimeout(temporizador);
            contenedor.classList.remove('con-fondo');
            n.style.animation = 'fadeOut 0.25s ease forwards';
            setTimeout(() => n.remove(), 250);
        };
        n.querySelector('.notification-close').addEventListener('click', cerrar);
        const temporizador = setTimeout(cerrar, 3200);
    }
}
