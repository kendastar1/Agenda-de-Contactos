/* ============================================================
   COMPONENTE: VISTA (recurso visual de las tarjetas de resumen)
   PATRONES: ninguno. Solo datos de presentación (ilustraciones 3D).
   ============================================================ */
// Ilustraciones 3D de las tarjetas del resumen: [archivo, left%, top%, ancho%, opacidad]
const DECO_TARJETAS = {
    todas: [
        ['tile_verde', 50, 76, 19], ['tile_azul', 1, 3, 23], ['plus', 29, 9, 8, .9], ['tile_morado', 42, 0, 21],
        ['libro', 19, 29, 56], ['telefono', 76, 31, 23], ['tile_amarillo', 76, 62, 23],
        ['plus_s', 66, 74, 6, .85], ['dot2', 68, 14, 4, .9], ['dot1', 1, 42, 3.5, .9]
    ],
    familia: [
        ['fam_tile_morado', 1, 3, 23], ['fam_corazon_morado', 28, 8, 10], ['fam_casa', 43, 1, 26],
        ['fam_circulo_morado', 46, 74, 20], ['fam_libro', 8, 33, 68], ['fam_plus_verde', 78, 33, 10],
        ['fam_tile_amarillo', 76, 62, 22], ['fam_corazon_azul', 28, 78, 11],
        ['fam_plus_morado', 2, 70, 8, .9], ['fam_dot', 70, 80, 4, .9]
    ],
    trabajo: [
        ['trab_reloj', 50, 77, 19], ['trab_documento', 1, 3, 26], ['trab_plus_morado', 30, 9, 9, .95],
        ['trab_objetivo', 42, 0, 24], ['trab_maletin', 14, 30, 58], ['trab_grafica', 76, 31, 22],
        ['trab_calendario', 74, 60, 25], ['trab_dot', 70, 18, 4], ['trab_plus_morado2', 3, 72, 7, .9]
    ],
    estudio: [
        ['est_estrella', 47, 82, 14], ['est_libro_abierto', 0, 4, 36], ['est_bombilla', 40, 0, 24],
        ['est_libros', 18, 28, 52], ['est_cuaderno', 76, 30, 22], ['est_globo', 74, 56, 22],
        ['est_lapiz', 2, 42, 14], ['est_dot_azul', 70, 22, 4], ['est_dot', 4, 70, 4, .9]
    ],
    amigos: [
        ['ami_burbuja_corazon', 46, 78, 18], ['ami_burbuja', 1, 2, 26], ['ami_plus', 29, 12, 7, .95],
        ['ami_manos', 36, 0, 28], ['ami_trio', 12, 36, 64], ['ami_sonrisa', 76, 28, 22],
        ['ami_tile_agregar', 76, 58, 22], ['ami_estrella', 24, 66, 9], ['ami_dot', 68, 20, 4, .95]
    ],
    otros: [
        ['otr_pregunta', 46, 78, 18], ['otr_carpeta', 1, 3, 26], ['otr_plus', 29, 12, 7, .95],
        ['otr_estrella', 38, 0, 24], ['otr_caja', 8, 36, 68], ['otr_regalo', 76, 28, 22],
        ['otr_pin', 77, 56, 17], ['otr_dot', 69, 18, 4, .95], ['otr_plus_azul', 26, 70, 7, .9]
    ]
};
function decoTarjeta(clave) {
    const items = DECO_TARJETAS[clave];
    if (!items) return '';
    const imgs = items.map(([f, l, t, w, o = 1]) =>
        `<img src="img/deco3d/${f}.png" alt="" class="md-img" style="left:${l}%;top:${t}%;width:${w}%${o !== 1 ? `;opacity:${o}` : ''}">`).join('');
    return `<span class="main-deco" aria-hidden="true"><span class="md-circle md-circle-b"></span>${imgs}</span>`;
}
