/* ============================================================
   COMPONENTE: CONTROLADOR (delgado)
   PATRONES: MVC (rol de Controlador) y Observer (es el OBSERVADOR: se
   suscribe a la agenda y vuelve a pintar cuando el Modelo avisa un cambio).
   Solo coordina: traduce eventos de la Vista en llamadas al Modelo y
   entrega los resultados a la Vista. No valida ni calcula reglas de negocio.
   Guarda únicamente el estado de la pantalla (filtros, página, edición).
   ============================================================ */
class ControladorAgenda {
    static REGISTROS_POR_PAGINA = 10;

    constructor(agenda, vista) {
        this.agenda = agenda;
        this.vista = vista;
        this.filtros = { texto: '', categoria: 'todas', fecha: 'todos', orden: 'asc' };
        this.pagina = 1;
        this.idEditando = null;   // null = contacto nuevo
        this.idAEliminar = null;
        this.fotoActual = null;   // data URL elegida en el formulario
        this.diaPintado = null;   // día con que se pintó la pantalla por última vez
    }

    iniciar() {
        this.vista.enlazar({
            nuevoContacto: () => this.#abrirNuevo(),
            buscar: texto => this.#cambiarFiltro('texto', texto, false),
            elegirCategoria: cat => this.#elegirCategoria(cat),
            elegirFecha: valor => this.#elegirFecha(valor),
            elegirOrden: valor => this.#elegirOrden(valor),
            limpiarFiltros: () => this.#limpiarFiltros(),
            irAPagina: n => { this.pagina = n; this.#refrescarLista(); },
            verContacto: id => { const c = this.agenda.obtener(id); if (c) this.vista.abrirDetalle(c); },
            editarContacto: id => this.#abrirEdicion(id),
            pedirEliminar: id => this.#pedirEliminar(id),
            confirmarEliminar: () => this.#confirmarEliminar(),
            elegirFoto: archivo => this.#elegirFoto(archivo),
            guardar: () => this.#guardar(),
            pestanaVisible: () => this.#alVolverALaPestana()
        });
        // Observer: cualquier cambio del Modelo repinta la pantalla
        this.agenda.suscribir(() => this.#refrescar());
        this.#refrescar();
    }

    // ---- Filtros y navegación ----
    #cambiarFiltro(clave, valor, repintarTodo = true) {
        this.filtros[clave] = valor;
        this.pagina = 1;
        repintarTodo ? this.#refrescar() : this.#refrescarLista();
    }

    // Fecha de nacimiento: no repinta las tarjetas del resumen (así la insignia ✓ no se anima de nuevo);
    // solo actualiza los botones de filtro y la lista.
    #elegirFecha(valor) {
        this.filtros.fecha = valor;
        this.pagina = 1;
        this.vista.renderizarFiltros(this.filtros, this.agenda.resumen('categoria'));
        this.#refrescarLista();
        this.vista.animarAccion('fecha', valor);
    }

    // Orden: igual que la fecha, no repinta las tarjetas del resumen.
    #elegirOrden(valor) {
        this.filtros.orden = valor;
        this.pagina = 1;
        this.vista.renderizarFiltros(this.filtros, this.agenda.resumen('categoria'));
        this.#refrescarLista();
        this.vista.animarAccion('orden');
    }

    #elegirCategoria(cat) {
        if (cat === 'todas') {
            // "Total": muestra todos los contactos (limpia búsqueda y filtros)
            this.vista.limpiarBusqueda();
            this.filtros.texto = '';
            this.filtros.fecha = 'todos';
            this.#cambiarFiltro('categoria', 'todas');
            return;
        }
        this.#cambiarFiltro('categoria', this.filtros.categoria === cat ? 'todas' : cat);
    }

    #limpiarFiltros() {
        this.vista.limpiarBusqueda();
        const cambiaCategoria = this.filtros.categoria !== 'todas';
        this.filtros = { texto: '', categoria: 'todas', fecha: 'todos', orden: 'asc' };
        this.pagina = 1;
        if (cambiaCategoria) { this.#refrescar(); this.vista.animarAccion('limpiar'); return; }
        // Si la categoría ya era "todas", las tarjetas no cambian: no se repintan (el ✓ no se anima)
        this.vista.renderizarFiltros(this.filtros, this.agenda.resumen('categoria'));
        this.#refrescarLista();
        this.vista.animarAccion('limpiar');
    }

    // ---- Alta y edición ----
    #abrirNuevo() {
        this.idEditando = null;
        this.fotoActual = null;
        this.vista.abrirFormulario();
    }

    #abrirEdicion(id) {
        const contacto = this.agenda.obtener(id);
        if (!contacto) return;
        this.idEditando = id;
        this.fotoActual = contacto.foto;
        this.vista.abrirFormulario(contacto);
    }

    async #elegirFoto(archivo) {
        if (!archivo) return;
        try {
            this.fotoActual = await this.vista.procesarFoto(archivo);
            this.vista.mostrarFoto(this.fotoActual);
        } catch (error) {
            this.vista.notificar(error.message, 'warning');
            this.vista.limpiarInputFoto();
        }
    }

    #guardar() {
        const dto = new ContactoDTO({ ...this.vista.leerFormulario(), foto: this.fotoActual });
        try {
            const resultado = this.idEditando
                ? this.agenda.actualizar(this.idEditando, dto)
                : this.agenda.agregar(dto);
            if (!resultado.ok) {
                this.vista.mostrarErrores(resultado.errores);
                this.vista.notificar('Revisa los campos marcados', 'warning');
                return;
            }
            this.vista.notificar(this.idEditando ? 'Los datos del contacto se actualizaron' : 'Contacto agregado a la agenda');
            this.vista.cerrarModal('contactoModal');
        } catch (error) {
            this.vista.notificar(error.message, 'error');
        }
    }

    // ---- Eliminación ----
    #pedirEliminar(id) {
        const contacto = this.agenda.obtener(id);
        if (!contacto) return;
        this.idAEliminar = id;
        this.vista.abrirConfirmarEliminar(contacto.nombreCompleto);
    }

    #confirmarEliminar() {
        if (this.idAEliminar === null) return;
        try {
            if (this.agenda.eliminar(this.idAEliminar)) this.vista.notificar('El contacto ha sido eliminado');
        } catch (error) {
            this.vista.notificar(error.message, 'error');
        }
        this.idAEliminar = null;
        this.vista.cerrarModal('deleteModal');
    }

    // Al volver a la pestaña solo se repinta si cambió el día (cumpleaños de hoy); así no se reinicia la lista
    #alVolverALaPestana() {
        if (this.agenda.hoy().toDateString() !== this.diaPintado) this.#refrescar();
    }

    // ---- Pintado: pide datos al Modelo y se los entrega a la Vista ----
    #refrescar() {
        this.diaPintado = this.agenda.hoy().toDateString();
        const porCategoria = this.agenda.resumen('categoria');
        this.vista.renderizarResumen(porCategoria, this.filtros.categoria);
        this.vista.renderizarFiltros(this.filtros, porCategoria);
        this.vista.renderizarCampana(this.agenda.resumen('cumpleanos'), this.agenda.hoy());
        this.#refrescarLista();
    }

    #refrescarLista() {
        const filtrados = this.agenda.consultar(this.filtros);
        const total = filtrados.length;
        const porPagina = ControladorAgenda.REGISTROS_POR_PAGINA;
        const totalPaginas = Math.max(1, Math.ceil(total / porPagina));
        this.pagina = Math.min(this.pagina, totalPaginas);
        const inicio = (this.pagina - 1) * porPagina;
        const { texto, categoria, fecha, orden } = this.filtros;

        this.vista.renderizarLista({
            contactos: filtrados.slice(inicio, inicio + porPagina),
            total, inicio, totalPaginas,
            pagina: this.pagina,
            hayFiltro: texto.trim() !== '' || categoria !== 'todas' || fecha !== 'todos' || /^[A-Z]-[A-Z]$/.test(orden),
            hoy: this.agenda.hoy()
        });
    }
}
