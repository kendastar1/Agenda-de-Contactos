/* ============================================================
   COMPONENTE: REPOSITORIO (acceso al almacenamiento del navegador)
   PATRÓN GoF ESTRUCTURAL: Adapter.
   Problema que resuelve: localStorage solo entiende cadenas de texto
   (getItem/setItem). El repositorio necesita leer y escribir OBJETOS.
   El adaptador convierte esa interfaz a leerObjeto/escribirObjeto, y
   permite cambiar el almacenamiento (por ejemplo a memoria) sin tocar
   el repositorio.
   ============================================================ */
class AdaptadorAlmacenamiento {
    constructor(almacen) {
        this.almacen = almacen; // objeto con getItem / setItem (localStorage)
    }

    leerObjeto(clave, valorPorDefecto = null) {
        try {
            const texto = this.almacen.getItem(clave);
            return texto === null ? valorPorDefecto : JSON.parse(texto);
        } catch (error) {
            console.error('Error al leer:', error);
            return valorPorDefecto;
        }
    }

    escribirObjeto(clave, valor) {
        try {
            this.almacen.setItem(clave, JSON.stringify(valor));
        } catch (error) {
            console.error('Error al guardar:', error);
            throw new Error('No se pudieron guardar los datos');
        }
    }
}
