/* ============================================================
   COMPONENTE: REPOSITORIO (persistencia de contactos)
   PATRÓN ARQUITECTÓNICO: Repository.  PATRÓN GoF CREACIONAL: Singleton.
   Repository: el resto de la aplicación ve una "colección" de contactos
   y no sabe nada de localStorage ni de JSON.
   Singleton: debe existir UNA sola copia de la lista en memoria; si
   hubiera dos repositorios, uno sobrescribiría los datos del otro.
   Se obtiene con RepositorioContactos.obtenerInstancia(adaptador).
   ============================================================ */
class RepositorioContactos {
    static #instancia = null;
    static CLAVE = 'agendaContactos';

    #adaptador;
    #contactos = [];

    constructor(adaptador) {
        if (RepositorioContactos.#instancia) {
            throw new Error('Use RepositorioContactos.obtenerInstancia()');
        }
        this.#adaptador = adaptador;
        const registros = adaptador.leerObjeto(RepositorioContactos.CLAVE, []);
        this.#contactos = registros.map(FabricaContactos.desdeRegistro);
    }

    static obtenerInstancia(adaptador) {
        if (!RepositorioContactos.#instancia) {
            RepositorioContactos.#instancia = new RepositorioContactos(adaptador);
        }
        return RepositorioContactos.#instancia;
    }

    obtenerTodos() {
        return [...this.#contactos];
    }

    obtenerPorId(id) {
        return this.#contactos.find(c => c.id === id) || null;
    }

    // Inserta, o reemplaza si el id ya existe
    guardar(contacto) {
        const i = this.#contactos.findIndex(c => c.id === contacto.id);
        if (i === -1) this.#contactos.push(contacto);
        else this.#contactos[i] = contacto;
        this.#persistir();
        return contacto;
    }

    eliminar(id) {
        const antes = this.#contactos.length;
        this.#contactos = this.#contactos.filter(c => c.id !== id);
        const eliminado = this.#contactos.length < antes;
        if (eliminado) this.#persistir();
        return eliminado;
    }

    #persistir() {
        this.#adaptador.escribirObjeto(RepositorioContactos.CLAVE, this.#contactos);
    }
}
