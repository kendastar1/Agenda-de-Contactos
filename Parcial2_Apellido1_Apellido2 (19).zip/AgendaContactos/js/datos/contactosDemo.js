/* ============================================================
   COMPONENTE: DATOS DE EJEMPLO (solo para demostración)
   PATRONES: ninguno. Usa el servicio de la agenda como cualquier cliente.
   Se carga UNA sola vez (bandera en el almacenamiento). Para quitar los
   ejemplos basta con no invocar cargarContactosDemo() en main.js.
   ============================================================ */
function cargarContactosDemo(agenda, almacenamiento) {
    const BANDERA = 'agendaDemoCargada';
    if (almacenamiento.leerObjeto(BANDERA, false)) return;

    const hoy = agenda.hoy();
    // Cumpleaños dentro del mes actual para que se vea la estrategia "del mes"
    const mesActual = dia => `1990-${String(hoy.getMonth() + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;

    const demo = [
        ['Ana María Gómez',        'familia', '3001234501', 'ana.gomez@correo.com',       mesActual(hoy.getDate())],
        ['Andrés Felipe Pérez',    'amigos',  '3001234502', 'andres.perez@correo.com',    mesActual(5)],
        ['Beatriz Elena Ruiz',     'familia', '3001234503', 'beatriz.ruiz@correo.com',    '1968-11-02'],
        ['Camila Rojas',           'estudio', '3001234504', 'camila.rojas@correo.com',    '2001-07-21'],
        ['Carlos Eduardo Soto',    'trabajo', '3001234505', 'carlos.soto@correo.com',     null],
        ['Daniela Vargas',         'amigos',  '3001234506', 'daniela.vargas@correo.com',  '1998-12-09'],
        ['Diego Armando Cárdenas', 'trabajo', '3001234507', 'diego.cardenas@correo.com',  '1989-05-30'],
        ['Elena Patricia Mora',    'familia', '3001234508', 'elena.mora@correo.com',      '1975-09-17'],
        ['Esteban Quintero',       'estudio', '3001234509', 'esteban.quintero@correo.com', null],
        ['Fabiola Castaño',        'otros',   '3001234510', 'fabiola.castano@correo.com', '1985-02-25'],
        ['Felipe Andrés Ortiz',    'amigos',  '3001234511', 'felipe.ortiz@correo.com',    mesActual(12)],
        ['Gabriela Londoño',       'trabajo', '3001234512', 'gabriela.londono@correo.com', null],
        ['Hernán Darío Pardo',     'familia', '3001234513', 'hernan.pardo@correo.com',    '1960-04-12'],
        ['Isabella Mejía',         'estudio', '3001234514', 'isabella.mejia@correo.com',  '2002-10-03'],
        ['Jhon Alexander Díaz',    'amigos',  '3001234515', 'jhon.diaz@correo.com',       null],
        ['Juliana Restrepo',       'trabajo', '3001234516', 'juliana.restrepo@correo.com', '1991-06-19'],
        ['Karen Lucía Salazar',    'otros',   '3001234517', 'karen.salazar@correo.com',   null],
        ['Laura Sofía Herrera',    'amigos',  '3001234518', 'laura.herrera@correo.com',   mesActual(18)],
        ['Luis Fernando Cano',     'familia', '3001234519', 'luis.cano@correo.com',       '1971-03-05'],
        ['Manuela Ibáñez',         'estudio', '3001234520', 'manuela.ibanez@correo.com',  null],
        ['Mateo Ríos',             'amigos',  '3001234521', 'mateo.rios@correo.com',      '2000-11-15'],
        ['Natalia Bermúdez',       'trabajo', '3001234522', 'natalia.bermudez@correo.com', mesActual(27)],
        ['Oscar Iván Peña',        'otros',   '3001234523', 'oscar.pena@correo.com',      null],
        ['Paola Andrea Luna',      'familia', '3001234524', 'paola.luna@correo.com',      mesActual(2)],
        ['Ricardo Vega',           'trabajo', '3001234525', 'ricardo.vega@correo.com',    '1979-09-01'],
        ['Sara Valentina Gil',     'estudio', '3001234526', 'sara.gil@correo.com',        '2003-05-11'],
        ['Santiago Medina',        'amigos',  '3001234527', 'santiago.medina@correo.com', null],
        ['Tatiana Ospina',         'otros',   '3001234528', 'tatiana.ospina@correo.com',  '1993-02-14'],
        ['Valeria Arango',         'familia', '3001234529', 'valeria.arango@correo.com',  '2005-08-29'],
        ['Yesid Camilo Torres',    'trabajo', '3001234530', 'yesid.torres@correo.com',    null]
    ];


    demo.forEach(([nombreCompleto, categoria, telefono, email, fechaNacimiento], i) => {
        const id = 'demo-' + String(i + 1).padStart(2, '0');
        agenda.agregar(new ContactoDTO({ nombreCompleto, categoria, telefono, email, fechaNacimiento }), id);
    });
    almacenamiento.escribirObjeto(BANDERA, true);
}
