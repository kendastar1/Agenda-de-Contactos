/* ============================================================
   COMPONENTE: MODELO (contrato de las estrategias de resumen)
   PATRÓN GoF DE COMPORTAMIENTO: Strategy (interfaz común).
   Cada estrategia recibe la lista de contactos y devuelve DATOS
   (nunca HTML): dibujar el resultado es trabajo de la Vista.
   ============================================================ */
class EstrategiaResumen {
    get id() { throw new Error('Debe implementarse'); }
    calcular(_contactos, _hoy) { throw new Error('Debe implementarse'); }
}
