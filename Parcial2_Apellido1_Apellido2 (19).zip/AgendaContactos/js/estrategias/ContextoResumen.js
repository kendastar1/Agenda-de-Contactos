/* ============================================================
   COMPONENTE: MODELO (contexto del Strategy)
   PATRÓN GoF DE COMPORTAMIENTO: Strategy (clase Contexto).
   Guarda las estrategias disponibles y ejecuta la pedida por id, sin
   condicionales (if/switch) en quien la usa: agregar un resumen nuevo
   es crear otra estrategia y registrarla en main.js.
   ============================================================ */
class ContextoResumen {
    constructor(estrategias) {
        this.estrategias = estrategias;
    }

    calcular(contactos, hoy, id) {
        const estrategia = this.estrategias.find(e => e.id === id);
        if (!estrategia) throw new Error(`Estrategia desconocida: ${id}`);
        return estrategia.calcular(contactos, hoy);
    }
}
