/* ============================================================
   COMPONENTE: MODELO (estrategia concreta #2)
   PATRÓN GoF DE COMPORTAMIENTO: Strategy.
   Contactos con cumpleaños en el MES ACTUAL, ordenados por día.
   El mes sale de la fecha recibida, así se puede probar con cualquier fecha.
   ============================================================ */
class CumpleanosDelMes extends EstrategiaResumen {
    get id() { return 'cumpleanos'; }

    calcular(contactos, hoy) {
        const mes = hoy.getMonth() + 1;
        const items = contactos
            .filter(c => c.cumpleEnMes(mes))
            .map(contacto => {
                const f = parsearFecha(contacto.fechaNacimiento);
                return {
                    contacto,
                    dia: f.dia,
                    edad: hoy.getFullYear() - f.anio,   // edad que cumple este año
                    esHoy: f.dia === hoy.getDate(),
                    diasFaltantes: f.dia - hoy.getDate() // negativo = ya pasó
                };
            })
            .sort((a, b) => a.dia - b.dia || compararNombres(a.contacto.nombreCompleto, b.contacto.nombreCompleto));
        return { id: this.id, mes, nombreMes: MESES[mes - 1], items };
    }
}
