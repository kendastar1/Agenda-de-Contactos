/* ============================================================
   COMPONENTE: MODELO (estrategia concreta #1)
   PATRÓN GoF DE COMPORTAMIENTO: Strategy.
   Resumen por categoría: cuántos contactos hay en cada una.
   ============================================================ */
class ResumenPorCategoria extends EstrategiaResumen {
    get id() { return 'categoria'; }

    calcular(contactos) {
        const categorias = Object.entries(CATEGORIAS).map(([clave, etiqueta]) => ({
            clave,
            etiqueta,
            cantidad: contactos.filter(c => c.categoria === clave).length
        }));
        return { id: this.id, total: contactos.length, categorias };
    }
}
